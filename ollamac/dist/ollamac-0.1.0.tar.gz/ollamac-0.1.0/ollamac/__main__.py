from ollamac.ollamac import OlcRunner

OlcRunner().run()
